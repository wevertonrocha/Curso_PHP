#### Projeto utilizado no treinamento de orientação a objetos com PHP da DIO

##### Configurando o autoload via Composer
`composer dump-autoload`

##### Executando o projeto através do CLI do PHP
`php debug/operacoesContaCorrente.php`

`php debug/operacoesContaPoupanca.php`
